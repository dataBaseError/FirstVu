/**
 * A file that contains methods for validating input.
 *
 * @author Ryan Crawford
 * @author Khalil Fazal
 * @author Joseph Heron
 * @author Carly Marshall
 */
#include "../include/validation.h"

// Cast to string
// match with [0-9]+\.[0-9]{2}
bool validBalance(double balance) {
   return true;
	/**
	 * This method is current un-implemented but in the final build will be used
	 * to determine if a users balance is valid
	 */
}

bool validUsername(string username) {
	return true;
	/**
	 * This method is current un-implemented but in the final build will be used
	 * to determine if a username is valid
	 */
}

bool validEventName(string event) {
	return true;
	/**
	 * This method is current un-implemented but in the final build will be used
	 * to determine if an event name is valid
	 */
}


bool validAccountType(string type) {
	return true;
	/**
	 * This method is current un-implemented but in the final build will be used
	 * to determine if an account type is valid
	 */
}


bool validPrice(double price) {
	return true;
	/**
	 * This method is current un-implemented but in the final build will be used
	 * to determine if a price is valid
	 */
}
